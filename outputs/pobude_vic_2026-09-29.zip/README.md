# Pobude meščanov – zajem ČS Vič

Zbirka javnih pobud s portala [pobude.ljubljana.si](https://pobude.ljubljana.si/).

Obseg določa izključno **spustni filter »VIČ«**, ob nastavitvah **»Vse pobude«** in **obdobje »Vse«**, na seznamih odgovorjenih in neodgovorjenih pobud. Prostorsko preverjanje, premeščanje med četrtnimi skupnostmi in iskanje pobud iz drugih četrti niso del tega zajema.

Zajem 29. septembra 2026 vsebuje **2.975 pobud: 2.952 odgovorjenih in 23 neodgovorjenih**. Vseh 2.975 ima geografsko točko. Datumi prijav segajo od 9. decembra 2008 do 27. septembra 2026. Pri 430 pobudah je skupaj 614 povezav iz galerij prilog. Naknadna ponovitev obeh filtriranih seznamov je potrdila nespremenjen nabor, statuse, naslove in datume seznama.

Pri 459 pobudah je ohranjena številčna šifra kategorije, ki je sedanji spustni meni ne vsebuje; njihovega naziva kategorije zato nismo ugibali. Vsebina teh pobud, odgovori in lokacije so zajeti.

## Datoteke

Zajem je v mapi [data/vic_2026-09-29](data/vic_2026-09-29/).

| Datoteka | Namen |
|---|---|
| `pobude_vic.json` | Celotna strukturirana zbirka, z besedili, HTML, datumi, koordinatami, kategorijami in povezavami do prilog. |
| `pobude_vic.jsonl` | Enak nabor, ena pobuda na vrstico, primeren za nadaljnjo strojno obdelavo. |
| `pobude_vic.sqlite` | Lokalna podatkovna baza; tabela `initiatives`, ena vrstica na pobudo. Celoten zapis je tudi v stolpcu `record_json`. |
| `pobude_vic.geojson` | Geografski izvoz; koordinate so v vrstnem redu **zemljepisna dolžina, zemljepisna širina**, WGS84. |
| `index.json` | Pobude in statusi iz obeh filtriranih seznamov portala. |
| `categories.json` | Šifrant vrst pobud, prebran iz spustnega menija portala. |
| `geometry.json` | Povezava ID-ja pobude z atributi in točko iz kartografskega servisa. |
| `capture_report.json` | Števila zapisov, čas zajema, manjkajoči podatki in morebitne napake. |
| `source_list_verification.json` | Primerjava seznamov pred in po zajemu. |
| `validation_report.json` | Končna primerjava izvozov, identifikatorjev, koordinat in kontrolnih vsot izvirnikov. |
| `checksums.sha256` | Kontrolne vsote vseh podatkovnih datotek. |
| `raw/details/<ID>.txt` | Izvirni besedilni odgovor strani za posamezno pobudo; ohranjen pred razčlenjevanjem. |
| `raw/*_list.txt` | Izvirna filtrirana seznama. |
| `raw/geometry_*.json` | Izvirni odgovori kartografskega servisa v paketih do 200 ID-jev. |
| `raw/*_page.html` | Posnetka strani, vključno s šifranti in nastavitvami obrazca. |

## Pomen pomembnih polj

- `id`: identifikator pobude na portalu. Povezuje sezname, podrobnosti in kartografski zapis `MOL_VNESENE_POBUDE_FC_ID`. ArcGIS `OBJECTID` je ločen identifikator in ni uporabljen kot ključ pobude.
- `portal_status`: `odgovorjena` ali `neodgovorjena`. **To ni ocena razrešenosti problema.**
- `district`: četrtna skupnost iz podrobnosti pobude. Vključitev v zbirko določa filter seznama.
- `reported_date`, `published_date`, `last_response_date`: datum prijave, objave in zadnjega objavljenega odgovora, zapisani kot `YYYY-MM-DD`. Izvorni datumski nizi so ohranjeni v poljih s pripono `_raw`.
- `list_date`: datum iz seznama. Njegov pomen je odvisen od seznama; ne uporablja se samodejno kot datum prijave.
- `initiative_text`, `response_text`: očiščeni besedili. Celotna razpoložljiva vsebina odgovora je ohranjena tudi kot `responses_html`, vključno z morebitnimi dodatnimi odgovori v istem bloku.
- `respondents_text`: besedilo portala o pripravljavcu odgovora oziroma obravnavi. To ne dokazuje, kdo mora izvesti ukrep.
- `category_id`, `category`: kategorija iz kartografskega zapisa in njen naziv iz šifranta portala. Neznane šifre ostanejo ohranjene, naziv pa je prazen.
- `geometry_wgs84`: koordinati, ki ju vrne kartografski servis z `outSR=4326`. Točka ni bila prestavljena ali preverjena glede pripadnosti Viču.
- `source_x`, `source_y`: izvorni koordinati iz podrobnosti, brez pretvorbe; nista zemljepisna dolžina in širina.
- `gis_attributes`: izbrani atributi kartografskega servisa, vključno z izvornimi datumi. Njihova interna polja se ne interpretirajo kot dokaz izvedbe.
- `attachment_links`: povezave do slik in prilog iz obeh galerij. Slike in druge binarne priloge **niso prenesene**; zajeti so njihovi URL-ji in izvorni HTML galerij.
- `source_page`, `source_callback_argument`: izvorna stran in parameter, s katerim portal pridobi pobudo. Sam URL strani ne odpre nujno izbrane pobude.
- `captured_at`, `raw_detail_path`, `raw_sha256`: čas prenosa posameznega izvirnika, njegova pot in kontrolna vsota UTF-8 besedila.

## Omejitve zajema

Zajem ohranja javno vsebino, ki jo portal vrne v trenutku prenosa. Ne predstavlja zgodovine vseh prejšnjih različic odgovorov ali dokazila o izvedbi. `last_response_date` ni nujno datum prvega odgovora. Pobude z več odgovori v enem bloku še niso razdeljene na ločene dogodke; izvorni blok je shranjen v celoti.

V tej fazi ni izvedena tematska analiza, povezovanje podobnih pobud, ocenjevanje obljub ali preverjanje rešitev. Manjkajoče vrednosti se ne nadomeščajo z ugibanjem.

## Ponovitev zajema

Skript uporablja Pythonovo standardno knjižnico in običajne javne bralne zahtevke portala. Pridobi ASP.NET stanje obrazca, preveri možnost `VIČ` z vrednostjo `15`, prenese oba seznama, geografske podatke poveže samo z ID-ji iz teh seznamov in zaporedno pridobi podrobnosti. Izvorne odzive razčleni kot podatke; JavaScripta iz odgovorov ne izvaja.

```sh
python3 scripts/capture_pobude.py --folder data/vic_NOV_DATUM
```

Za nov posnetek uporabi novo mapo. Ponovitev v isti mapi je namenjena **nadaljevanju prekinjenega zajema**: že shranjenih podrobnosti ne prenese znova.

Za ponovno razčlenitev in izvoz obstoječega zajema brez omrežnih zahtevkov:

```sh
python3 scripts/capture_pobude.py --folder data/vic_2026-09-29 --export-only
```

Skript po vsakih 100 pobudah izpiše napredek, ob začasni omrežni napaki poskusi ponovno, končno popolnost pa zabeleži v `capture_report.json`. Morebitni izpuščeni ali nerazčlenljivi zapisi se izrecno navedejo kot napake.
