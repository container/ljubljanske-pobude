#!/usr/bin/env python3
"""Recheck the portal dropdown lists after capture to detect changes during the run."""
import json
from capture_pobude import ROOT, BASE, PAGES, Client, Markup, parse_list, save_json, now

folder = ROOT / 'data/vic_2026-09-29'
client = Client(folder)
original = json.loads((folder / 'index.json').read_text())
latest = []
for status, page in PAGES.items():
    body = client.request(BASE + page)
    (folder / 'raw' / (status + '_verification_page.html')).write_text(body, encoding='utf-8')
    parser = Markup(); parser.feed(body)
    form = dict(parser.hidden, __CALLBACKID='__Page', ddlVrstaPobude='0', ddlCetrtnaSkupnost='15', rbDatum='0')
    response = client.callback(status, form, '0::::15::::0::::getpobudaid')
    (folder / 'raw' / (status + '_verification_list.txt')).write_text(response, encoding='utf-8')
    latest.extend(parse_list(response, status))
before = {row['id']: row for row in original}
after = {row['id']: row for row in latest}
result = {'checked_at': now(), 'original_count': len(before), 'latest_count': len(after),
          'added_ids': sorted(after.keys() - before.keys()), 'removed_ids': sorted(before.keys() - after.keys()),
          'changed_list_rows': sorted(i for i in before.keys() & after.keys() if before[i] != after[i])}
result['unchanged'] = not (result['added_ids'] or result['removed_ids'] or result['changed_list_rows'])
save_json(folder / 'source_list_verification.json', result)
print(json.dumps(result, ensure_ascii=False))
if not result['unchanged']:
    raise SystemExit(1)
