﻿// JScript File
//position of the input div / variable holds clientside position, is set by server

 
           
    function fillListbox(){

             var ddlvp = jQuery("#ddlVrstaPobude");
             var ddlcs = jQuery("#ddlCetrtnaSkupnost");

           if(!ddlvp.length){
                alert("Napaka, poskusite znova");
                return;
            }else{
                    prikaziPobudo(ddlvp.val() + "::::" + ddlcs.val() + "::::" + jQuery("input[name='rbDatum']:checked").val() + '::::getpobudaid');
            }
        };

    function fillListboxVroce() {

            var ddlvp = jQuery("#ddlVrstaPobude");

            if (!ddlvp.length) {
                alert("Napaka, poskusite znova");
                return;
            } else {
                prikaziPobudo(ddlvp.val() + '::::getpobudaidvroce');
            }
    };

    function isciPobudo() {

        var searchStr = "";
        if (jQuery("#query").val().length > 0) {
            searchStr = jQuery("#query").val();
            window.open("PrikazRezultatovIskanja.aspx?query=" + searchStr, "_self");
        }

    }
    
    function pobudePrikazi(IDpobude){
       
        clearPobudeLocationLayer();
        
        if (!IDpobude) {
            alert("Napaka, poskusite znova");
            return;
        }else{
            if (IDpobude !== '0') {

                prikaziPobudo(IDpobude + "::::getpobudatext");
            }
        }
    };

    function scrollToElement(element) {
        require(["dojo/dom", "dojo/dom-style", "dojo/window"], function (dom, domStyle, win) {
            win.scrollIntoView(element);
        });
    }

