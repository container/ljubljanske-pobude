﻿/// <reference assembly="ESRI.ArcGIS.ADF.Web.UI.WebControls" name="ESRI.ArcGIS.ADF.Web.UI.WebControls.Runtime.JavaScript.references.js"/>
// JScript File
//require(["dojo/domReady!"], function () {
//    if (idpobude == undefined) return;
//    prikaziPobudo(idpobude + '::::' + 0 + '::::getpobudafirst');
//});


function clearresponse() {
    var containerPobuda = jQuery("#containerPobuda");
    containerPobuda.removeClass("hidden");

      jQuery("#pDatumPrijave").html('');
      jQuery("#pCetrtnaSkupnost").html('');
      jQuery("#pNaslovPobude").html('');
      jQuery("#pVsebinaPobude").html('');
      jQuery("#pDatumObjave").html('');
      jQuery("#pOddelki").html('');


      
  };


  function setPobudaInfo(datumprijave, cetrtnaskupnost, naslovpobude, vsebinapobude, pobudaslike, datumobjave, dodeljenci, pntx, pnty) {
      clearresponse();
      
      
    jQuery("#pDatumPrijave").html(datumprijave);

    jQuery("#pCetrtnaSkupnost").html(cetrtnaskupnost)
    
    jQuery("#pNaslovPobude").html(naslovpobude);

    var decodedVsebina = jQuery("<div/>").html(vsebinapobude).text();

    jQuery("#pVsebinaPobude").html(decodedVsebina);

    var decodedSlike = jQuery("<div/>").html(pobudaslike).text();

    jQuery("#pictGallery").html(decodedSlike);
            
    jQuery("#pDatumObjave").html(datumobjave);    
    
    jQuery("#pOddelki").html(dodeljenci);        
  
        require(["esri/geometry/Point"], function (Point) {
            var p = new Point(pntx, pnty, gdiMap.spatialReference)
            panMapToCentre(p);
            placePobudeLocationLayer(p);
        });       
    
};

